from django.contrib import admin
from .models import UserPassword


# Register models here to show into admin panel.
admin.site.register(UserPassword)
